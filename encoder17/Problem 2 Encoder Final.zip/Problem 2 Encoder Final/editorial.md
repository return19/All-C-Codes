Basic stack operations. Can be easily implemented using vector<> in stl c++.

http://www.cplusplus.com/reference/vector/vector/